import { journeyFrame, nearestOrbitPosition } from './motion.mjs';
import { playIntro } from './intro.mjs';

const chapters = [
  { id:'overview', name:'OVERVIEW', thai:'ภาพรวม', tag:'YOUR DAY, AT A GLANCE', copy:'หนึ่งวันของคุณ อยู่ในจักรวาลเดียวกัน', items:['เวลาใช้คอม การนอน และมื้ออาหารในหน้าเดียว','มองเห็นกิจวัตรของวันนี้','ย้อนกลับไปดูวันก่อนหน้า'] },
  { id:'screen', name:'SCREEN', thai:'เวลาใช้คอม', tag:'FOCUS & CREATE', copy:'ทุกช่วงเวลาหน้าจอ มีจังหวะของมัน', items:['เลือกกิจกรรม Work / Study / Game','เริ่มและหยุดจับเวลาเมื่อคุณต้องการ','รวมเวลาของแต่ละกิจกรรมในหนึ่งวัน'] },
  { id:'sleep', name:'SLEEP', thai:'การนอน', tag:'REST & RECHARGE', copy:'ให้คืนนี้ เป็นพื้นที่สำหรับการพักผ่อน', items:['บันทึกเวลาเข้านอนและเวลาตื่น','ดูระยะเวลานอนของคืนที่ผ่านมา','บันทึกความสดชื่นหลังตื่นด้วยตัวคุณเอง'] },
  { id:'meals', name:'MEALS', thai:'มื้ออาหาร', tag:'REFUEL YOUR DAY', copy:'เติมพลังให้ตัวเอง ก่อนเดินทางต่อ', items:['บันทึกมื้อเช้า กลางวัน และเย็น','แก้ไขหรือล้างเฉพาะมื้อที่เลือก','ดูบันทึกมื้ออาหารคู่กับกิจวัตรของวัน'] }
];
const $ = id => document.getElementById(id);
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let active = -1, raf = 0, opened = false;
let navigation = null, visualPosition = 0;
let touchY = null;
let introActive = true;
const scene = $('scene');
const shape = '<svg viewBox="0 0 400 120" preserveAspectRatio="none" aria-hidden="true"><path class="plate-depth" style="fill:#1665ff;stroke:none" d="M40.5 12.5Q199 29.2 374.8 12.5L400 117.5H0Z"/><path class="plate-face" d="M12 13Q200 -2 388 13L375 109Q200 94 25 109Z"/><path class="plate-rim" style="fill:#08e5ff;stroke:none"/><path class="plate-accent" style="fill:#08e5ff;stroke:none" d="M27.2 0H37.8L2.7 116.7H-8Z M374.8 2L390.1 0L404 92L390 88Z"/></svg>';
chapters.forEach((chapter, i) => {
  const button = document.createElement('button');
  button.className = 'orbit-card'; button.dataset.index = i;
  button.setAttribute('aria-label', `เลือก ${chapter.name} ${chapter.thai}`);
  button.innerHTML = `${shape}<svg class="side-label" viewBox="0 0 159 150" aria-hidden="true"><defs><path id="label-arc-${i}"/></defs><text><textPath href="#label-arc-${i}" startOffset="50%" text-anchor="middle">${chapter.name}</textPath></text></svg><span>${chapter.name}</span><small>${chapter.thai}</small>`;
  button.addEventListener('click', () => go(i));
  $('cards').append(button);
});
const cards = [...document.querySelectorAll('.orbit-card')];
const characters = [...document.querySelectorAll('.character')];
const textMeasure = document.createElement('canvas').getContext('2d');
for (let i = 0; i < 28; i++) {
  const star = document.createElement('i');
  star.style.cssText = `left:${(i * 37 + 11) % 100}%;top:${(i * 23 + 17) % 100}%;--s:${i % 7 === 0 ? 9 : 2}px;--delay:${i % 5}s`;
  $('stars').append(star);
}
function updateDetails() {
  const chapter = chapters[Math.max(0, active)];
  $('detail-title').textContent = chapter.name;
  $('detail-description').textContent = chapter.copy;
  $('detail-list').replaceChildren(...chapter.items.map(text => { const li = document.createElement('li'); li.textContent = text; return li; }));
}
function render(now = performance.now()) {
  raf = 0;
  if (navigation) {
    const fraction = Math.min(1, (now-navigation.start)/navigation.duration);
    const ease = fraction*fraction*(3-2*fraction);
    visualPosition = navigation.from+(navigation.to-navigation.from)*ease;
    if (fraction === 1) {
      visualPosition = ((Math.round(navigation.to)%4)+4)%4;
      navigation = null;
    }
  }
  const frame = journeyFrame(visualPosition, reduced.matches, true);
  scene.dataset.orbitPosition = visualPosition.toFixed(4);
  cards.forEach((card, i) => {
    const f = frame.cards[i];
    const mobile = innerWidth <= 600;
    const nativeScale = Math.max(.56, Math.min(1, scene.clientWidth / 1672));
    const frontScale = mobile ? Math.min(280, scene.clientWidth*.72)/603 : Math.min(1,scene.clientWidth/1672);
    const rest = Math.max(0,1-f.side-f.front);
    const width = (mobile ? 215 : Math.min(420, Math.max(230, innerWidth * .29))) * rest + (f.left ? 159 : 158) * nativeScale * f.side + 603*frontScale*f.front;
    const height = (mobile ? 80 : Math.min(134, Math.max(83, innerWidth * .09))) * rest + 150 * nativeScale * f.side + 144*frontScale*f.front;
    card.style.width = `${width}px`; card.style.height = `${height}px`;
    const path = card.querySelector('.plate-face');
    path.setAttribute('d', f.path);
    path.setAttribute('vector-effect', 'non-scaling-stroke');
    path.style.strokeWidth = String(2.7*rest + 6*nativeScale*f.side + 3*frontScale*f.front);
    path.style.fill = f.side > .8 ? '#040832' : f.front > .8 ? '#ffffff' : '';
    card.querySelector('.plate-depth').style.opacity = String(f.front);
    card.querySelector('.plate-accent').style.opacity = String(f.front);
    const rim = card.querySelector('.plate-rim');
    rim.style.opacity = String(f.side);
    rim.setAttribute('d',f.left ? 'M364.8 56L397.5 58.4L349.7 119.2L317 116Z' : 'M0 58.4L43 119.2L81 116L43 54.4Z');
    const label = card.querySelector('span');
    const sideLabel = card.querySelector('.side-label');
    sideLabel.style.opacity = String(f.side);
    sideLabel.querySelector('defs path').setAttribute('d',f.left ? 'M18 68Q72 106 128 117' : 'M32 119Q87 106 140 64');
    let sideFont = 43;
    textMeasure.font = `italic 900 ${sideFont}px Display`;
    const sideTextWidth = textMeasure.measureText(chapters[i].name).width;
    if(sideTextWidth > 105) sideFont *= 105/sideTextWidth;
    sideLabel.querySelector('text').style.cssText = `font:italic 900 ${sideFont}px Display;fill:white;stroke:none;letter-spacing:.5px`;
    const subtitle = card.querySelector('small');
    subtitle.style.opacity = String(rest ** 6);
    if (f.side + f.front > .001) {
      let font = (mobile ? 35 : Math.min(65, Math.max(30, innerWidth * .04))) * rest + 43*nativeScale*f.side + 104*frontScale*f.front;
      textMeasure.font = `italic 900 ${font}px Display`;
      if(f.side>.8 && textMeasure.measureText(chapters[i].name).width > width*.76) {
        font *= width*.76/textMeasure.measureText(chapters[i].name).width;
        textMeasure.font = `italic 900 ${font}px Display`;
      }
      const textWidth = textMeasure.measureText(chapters[i].name).width;
      const startX = (width-textWidth)/2;
      const startY = (height - font - 18) / 2;
      const sideX = width/2;
      const sideY = height/2 + 7*nativeScale;
      const frontX = width/2;
      const frontY = height/2;
      const centerX = (startX+textWidth/2)*rest + sideX*f.side + frontX*f.front;
      const centerY = (startY+font/2)*rest + sideY*f.side + frontY*f.front;
      label.style.cssText = `position:absolute;left:${centerX}px;top:${centerY}px;font-size:${font}px;white-space:nowrap;transform-origin:50% 50%;transform:translate(-50%,-50%) rotate(${(f.left?26:-26)*f.side}deg);text-align:left;width:max-content`;
      if (f.side > .8) label.style.color = '#ffffff';
    } else label.style.cssText = '';
    label.style.opacity = String(1-f.side);
    card.style.left = `${f.x * 100}%`; card.style.top = `${f.y * 100}%`;
    card.style.transform = `translate(-50%,-50%) perspective(900px) rotateY(${f.rotateY}deg) rotateZ(${f.rotateZ}deg) scale(${f.scale})`;
    card.style.zIndex = String(f.z + 5);
    card.classList.toggle('selected', frame.active === i);
    card.setAttribute('aria-current', frame.active === i ? 'page' : 'false');
    card.style.setProperty('--depth', f.depth);
  });
  characters.forEach((character, i) => {
    const f = frame.chapters[i];
    character.style.opacity = String(f.opacity);
    character.style.transform = `translate3d(${f.x}px,${f.y}px,0) scale(${f.scale})`;
    character.style.visibility = f.opacity < .001 ? 'hidden' : 'visible';
  });
  scene.style.setProperty('--travel', (1-Math.cos(frame.position*Math.PI/2))*1.5);
  if (active !== frame.active) {
    active = frame.active;
    const chapter = chapters[active];
    $('word').textContent = chapter.name;
    $('eyebrow').textContent = `0${active + 1} — ${chapter.tag}`;
    $('description').textContent = chapter.copy;
    $('announcement').textContent = `เลือก ${chapter.name} ${chapter.thai}`;
    scene.dataset.chapter = chapter.id;
    history.replaceState(null, '', `#${chapter.id}`);
    if (opened) updateDetails();
  }
  if (navigation) schedule();
}
function schedule() { if (!raf) raf = requestAnimationFrame(render); }
function go(index) {
  if(introActive) return;
  const target = (index + 4) % 4;
  const current = visualPosition;
  const to = nearestOrbitPosition(current,target);
  scene.dataset.rotationFrom = current.toFixed(4);
  scene.dataset.rotationTo = to.toFixed(4);
  if(reduced.matches || Math.abs(to-current)<.001) {
    navigation=null;
    visualPosition=target;
  } else {
    navigation={from:current,to,start:performance.now(),duration:Math.min(900,550+Math.abs(to-current)*100)};
  }
  schedule();
}
function setOpened(value) {
  opened = value; scene.classList.toggle('opened', opened);
  $('details').hidden = !opened;
  $('arena').inert = opened;
  $('open').hidden = opened; $('exit').hidden = opened;
  $('copy').hidden = opened;
  if (opened) { updateDetails(); $('return-menu').focus({ preventScroll:true }); }
  else $('open').focus({ preventScroll:true });
}
$('previous').addEventListener('click', () => go(active - 1));
$('next').addEventListener('click', () => go(active + 1));
$('open').addEventListener('click', () => setOpened(true));
$('exit').addEventListener('click', () => setOpened(true));
$('return-menu').addEventListener('click', () => setOpened(false));
document.querySelector('.brand').addEventListener('click', event => { event.preventDefault(); setOpened(false); go(0); });
addEventListener('keydown', event => {
  if (event.altKey || event.ctrlKey || event.metaKey || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName)) return;
  if (event.key === 'Escape') { event.preventDefault(); setOpened(!opened); }
  if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); go(active + (event.key === 'ArrowRight' ? 1 : -1)); }
  if (event.key === 'Enter' && event.target === document.body && !opened) { event.preventDefault(); setOpened(true); }
});
function moveOrbit(delta) {
  navigation = null;
  visualPosition += delta / Math.max(innerHeight,560);
  // Keep continuous movement at the seam while bounding floating-point growth.
  if (Math.abs(visualPosition)>400) visualPosition %= 4;
  schedule();
}
addEventListener('wheel', event => {
  if(introActive) {event.preventDefault();return;}
  if(opened) return;
  event.preventDefault();
  const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? innerHeight : 1;
  moveOrbit((event.deltaY || event.deltaX)*unit);
}, {passive:false});
scene.addEventListener('touchstart', event => {touchY=event.touches.length===1 ? event.touches[0].clientY : null;}, {passive:true});
scene.addEventListener('touchmove', event => {
  if(introActive || opened || touchY===null || event.touches.length!==1) return;
  const nextY=event.touches[0].clientY;
  const delta=touchY-nextY;
  if(Math.abs(delta)<4) return;
  event.preventDefault();
  touchY=nextY;
  moveOrbit(delta);
}, {passive:false});
scene.addEventListener('touchend',()=>{touchY=null;}, {passive:true});
scene.addEventListener('touchcancel',()=>{touchY=null;}, {passive:true});
addEventListener('resize', schedule);
reduced.addEventListener('change', schedule);
document.fonts.ready.then(schedule);
$('today').textContent = new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', weekday:'short' }).toUpperCase();
const requested = chapters.findIndex(chapter => `#${chapter.id}` === location.hash);
visualPosition = Math.max(0,requested);
render();
playIntro({overlay:$('intro'),journey:$('journey'),reducedMotion:reduced,onComplete:()=>{introActive=false;}});
