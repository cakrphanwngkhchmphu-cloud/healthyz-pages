// The opening owns its canvas and input lock; the orbit keeps its own timeline.
export function playIntro({ overlay, journey, reducedMotion, onComplete }) {
  const canvas = overlay.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const skip = overlay.querySelector('button');
  const title = overlay.querySelector('.intro-title');
  if(reducedMotion.matches || !ctx) {
    overlay.hidden=true;overlay.dataset.phase='skipped';journey.inert=false;onComplete();return;
  }
  let finished = false, raf = 0, width = 0, height = 0;
  let elapsed = 0, last = performance.now();
  const duration = 6800;
  const clamp = value => Math.max(0, Math.min(1, value));
  const smooth = value => { const p = clamp(value); return p*p*(3-2*p); };
  let seed = 729;
  const random = () => { seed = (seed*16807)%2147483647; return (seed-1)/2147483646; };
  const stars = Array.from({ length: 230 }, () => ({
    angle:random()*Math.PI*2, radius:.1+random()*1.15,
    depth:random(), size:.3+random()*1.3, tint:random()
  }));
  const worlds = [
    {x:-.66,y:-.35,z:1.15,size:.24,hue:221,rings:true},
    {x:.74,y:.24,z:1.48,size:.21,hue:193,rings:false},
    {x:-.37,y:.64,z:2.05,size:.16,hue:255,rings:false},
    {x:.48,y:-.51,z:2.45,size:.19,hue:219,rings:true},
    {x:-.84,y:.2,z:3.1,size:.15,hue:205,rings:false}
  ];
  // Cache the shaded worlds once instead of rebuilding surface detail per frame.
  const sprites = worlds.map(world => makeWorld(world.hue,world.rings));
  const destination = makeWorld(209,false);
  const background = new Image();
  background.src = 'assets/menu-space.png';

  function makeWorld(hue, rings) {
    const sprite = document.createElement('canvas');
    sprite.width = sprite.height = 640;
    const c = sprite.getContext('2d'), x = 320, y = 320, r = 190;
    const glow = c.createRadialGradient(x,y,r*.8,x,y,r*1.55);
    glow.addColorStop(0,`hsla(${hue},100%,60%,.3)`);
    glow.addColorStop(.65,`hsla(${hue},100%,65%,.08)`);
    glow.addColorStop(1,`hsla(${hue},100%,50%,0)`);
    c.fillStyle=glow; c.fillRect(0,0,640,640);
    if (rings) drawRing(.35);
    c.save(); c.beginPath(); c.arc(x,y,r,0,Math.PI*2); c.clip();
    const shade = c.createRadialGradient(x-r*.45,y-r*.55,r*.06,x+r*.3,y+r*.4,r*1.55);
    shade.addColorStop(0,`hsl(${hue-10},90%,86%)`);
    shade.addColorStop(.3,`hsl(${hue},90%,56%)`);
    shade.addColorStop(.67,`hsl(${hue+14},95%,24%)`);
    shade.addColorStop(1,'#02051b');
    c.fillStyle=shade; c.fillRect(0,0,640,640);
    for(let i=0;i<160;i++) {
      const a=random()*Math.PI*2, d=Math.sqrt(random())*r, cr=3+random()*21;
      const px=x+Math.cos(a)*d, py=y+Math.sin(a)*d;
      c.beginPath(); c.ellipse(px,py,cr,cr*(.35+random()*.7),a,0,Math.PI*2);
      c.fillStyle=i%3===0?'#b0efff1a':'#01115926'; c.fill();
      c.strokeStyle='#baffff14'; c.lineWidth=1.5; c.stroke();
    }
    const shadow = c.createLinearGradient(x-r,y-r,x+r,y+r);
    shadow.addColorStop(0,'#00104700'); shadow.addColorStop(.55,'#00062c16'); shadow.addColorStop(1,'#000516c9');
    c.fillStyle=shadow; c.fillRect(0,0,640,640); c.restore();
    c.beginPath(); c.arc(x,y,r,0,Math.PI*2);
    c.strokeStyle=`hsla(${hue-15},100%,85%,.75)`; c.lineWidth=2; c.stroke();
    if(rings) drawRing(.95,true);
    return sprite;
    function drawRing(alpha, front=false) {
      c.save(); c.translate(x,y); c.rotate(-.45); c.scale(1,.26);
      c.beginPath(); c.arc(0,0,r*1.5,front ? 0 : Math.PI,front ? Math.PI : Math.PI*3);
      c.strokeStyle=`hsla(${hue-15},100%,82%,${alpha})`; c.lineWidth=7; c.stroke();
      c.beginPath(); c.arc(0,0,r*1.57,front ? 0 : Math.PI,front ? Math.PI : Math.PI*3);
      c.strokeStyle=`hsla(${hue},100%,55%,${alpha*.65})`; c.lineWidth=2; c.stroke(); c.restore();
    }
  }
  function resize() {
    width=innerWidth; height=innerHeight;
    const ratio=Math.min(devicePixelRatio||1,1.75);
    canvas.width=Math.round(width*ratio); canvas.height=Math.round(height*ratio);
    ctx.setTransform(ratio,0,0,ratio,0,0);
  }
  function world(sprite,x,y,r) { ctx.drawImage(sprite,x-r*640/380,y-r*640/380,r*640/190,r*640/190); }
  function flight(t) {
    const p=clamp(t/4000), acceleration=p*p*p;
    const cx=width*.5, cy=height*.48, unit=Math.min(width,height);
    ctx.fillStyle='#01041b';ctx.fillRect(0,0,width,height);
    if(background.complete && background.naturalWidth) {
      const scale=Math.max(width/background.width,height/background.height)*(1.1+acceleration*.35);
      const bw=background.width*scale, bh=background.height*scale;
      ctx.globalAlpha=.4;ctx.drawImage(background,(width-bw)/2,(height-bh)/2,bw,bh);ctx.globalAlpha=1;
    }
    const fog=ctx.createRadialGradient(cx,cy,0,cx,cy,unit*.95);
    fog.addColorStop(0,'#127edb25');fog.addColorStop(.38,'#05226838');fog.addColorStop(1,'#010217af');
    ctx.fillStyle=fog;ctx.fillRect(0,0,width,height);
    // Perspective depth wraps stars outside the camera; their tails lengthen as speed rises.
    const travel=.12*p+acceleration*2.7;
    ctx.save();ctx.globalCompositeOperation='screen';ctx.lineCap='round';
    stars.forEach(star=>{
      const z=.12+((star.depth-travel)%1+1)%1;
      const radius=star.radius*unit*.4/z;
      const tail=radius*(.004+acceleration*.36);
      const a=star.angle+Math.sin(p*1.5)*.035;
      const x=cx+Math.cos(a)*radius,y=cy+Math.sin(a)*radius;
      const tx=cx+Math.cos(a)*(radius-tail),ty=cy+Math.sin(a)*(radius-tail);
      if(x < -100 || x>width+100 || y < -100 || y>height+100)return;
      const color=star.tint>.97?'#dc57ff':star.tint>.66?'#38b6ff':'#a7f8ff';
      ctx.globalAlpha=Math.min(.96,.4+.1/z);
      ctx.strokeStyle=color;ctx.lineWidth=Math.min(6,star.size/z*.55);
      ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(x,y);ctx.stroke();
      ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,Math.min(2.7,star.size/z*.28),0,Math.PI*2);ctx.fill();
    });
    ctx.restore();
    worlds.forEach((planet,i)=>{
      const z=planet.z-acceleration*3.5;
      if(z<.12)return;
      const x=cx+planet.x*unit/z, y=cy+planet.y*unit/z;
      const r=planet.size*unit*.45/z;
      if(Math.abs(x-cx)>width+r*2||Math.abs(y-cy)>height+r*2)return;
      world(sprites[i],x,y,r);
    });
    // The destination stays at the vanishing point and grows to fill the camera.
    const approach=1-Math.pow(p,2.8);
    const radius=unit*.085/Math.max(.018,approach);
    world(destination,cx,cy,radius);
    ctx.save();ctx.globalCompositeOperation='screen';
    const halo=ctx.createRadialGradient(cx,cy,radius*.9,cx,cy,radius*1.6);
    halo.addColorStop(0,`rgba(50,221,255,${.1+acceleration*.16})`);halo.addColorStop(1,'#00cfff00');
    ctx.fillStyle=halo;ctx.fillRect(0,0,width,height);ctx.restore();
    const vignette=ctx.createRadialGradient(cx,cy,unit*.2,cx,cy,Math.hypot(width,height)*.55);
    vignette.addColorStop(0,'#00000000');vignette.addColorStop(1,'#000315a8');
    ctx.fillStyle=vignette;ctx.fillRect(0,0,width,height);
  }
  function portal(t) {
    const p=smooth((t-4850)/1750), cx=width*.5, cy=height*.5;
    const radius=Math.hypot(width,height)*.59;
    const rx=2+radius*Math.pow(p,1.7),ry=height*.12+radius*Math.pow(p,.72);
    ctx.fillStyle='#000';ctx.fillRect(0,0,width,height);
    const edge=new Path2D();
    for(let i=0;i<=100;i++) {
      const a=i/100*Math.PI*2;
      const ripple=1+Math.sin(a*7+t*.003)*.015*(1-p);
      const x=cx+Math.cos(a)*rx*ripple,y=cy+Math.sin(a)*ry*ripple;
      i ? edge.lineTo(x,y) : edge.moveTo(x,y);
    }
    edge.closePath();
    ctx.save();ctx.globalCompositeOperation='destination-out';ctx.fill(edge);ctx.restore();
    ctx.save();ctx.globalCompositeOperation='source-over';
    ctx.strokeStyle='#0599ff';ctx.lineWidth=15*(1-p)+3;ctx.shadowColor='#08bcff';ctx.shadowBlur=35;
    ctx.stroke(edge);ctx.strokeStyle='#a7fcff';ctx.lineWidth=2+3*(1-p);ctx.shadowBlur=16;ctx.stroke(edge);
    ctx.shadowBlur=0;
    for(let i=0;i<35;i++) {
      const a=i/35*Math.PI*2+t*.0001;
      const x=cx+Math.cos(a)*rx,y=cy+Math.sin(a)*ry;
      ctx.fillStyle=i%6===0?'#b987ff':'#6cecff';
      ctx.globalAlpha=(1-p)*.8;ctx.beginPath();ctx.arc(x,y,1.5+(i%3),0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
  }
  function tick(now) {
    if(finished)return;
    // Do not jump past the story when the tab returns from the background.
    elapsed+=Math.min(now-last,80);last=now;
    const t=elapsed;
    ctx.clearRect(0,0,width,height);
    if(t<4000) {overlay.dataset.phase='flight';flight(t);}
    else if(t<4350) {
      overlay.dataset.phase='impact';flight(3990);
      ctx.fillStyle=`rgba(0,0,0,${smooth((t-4000)/350)})`;ctx.fillRect(0,0,width,height);
    } else if(t<4850) {overlay.dataset.phase='blackout';ctx.fillStyle='#000';ctx.fillRect(0,0,width,height);}
    else {overlay.dataset.phase='portal';portal(t);}
    title.style.opacity=String(smooth(t/500)*(1-smooth((t-650)/850)));
    title.style.transform=`translate(-50%,-50%) translateY(${smooth(t/1700)*-15}px)`;
    overlay.dataset.elapsed=String(Math.round(t));
    if(t>=duration) {finish();return;}
    raf=requestAnimationFrame(tick);
  }
  function keyboard(event) {
    if(finished)return;
    if(event.key==='Escape'||event.key==='Enter') {event.preventDefault();event.stopImmediatePropagation();finish(true);}
  }
  function changed() {if(reducedMotion.matches)finish(true);}
  function visibility() {
    cancelAnimationFrame(raf);
    if(!document.hidden&&!finished) {last=performance.now();raf=requestAnimationFrame(tick);}
  }
  function finish(skipped=false) {
    if(finished)return;
    finished=true;cancelAnimationFrame(raf);
    overlay.hidden=true;overlay.dataset.phase=skipped?'skipped':'complete';
    journey.inert=false;document.documentElement.classList.remove('intro-playing');
    removeEventListener('resize',resize);
    removeEventListener('keydown',keyboard,true);
    document.removeEventListener('visibilitychange',visibility);
    reducedMotion.removeEventListener('change',changed);
    skip.removeEventListener('click',skipOpening);
    if(document.activeElement===skip)journey.querySelector('#open').focus({preventScroll:true});
    onComplete();
  }
  function skipOpening(){finish(true);}
  journey.inert=true;document.documentElement.classList.add('intro-playing');
  skip.addEventListener('click',skipOpening);
  addEventListener('keydown',keyboard,true);addEventListener('resize',resize);
  document.addEventListener('visibilitychange',visibility);
  reducedMotion.addEventListener('change',changed);
  resize();raf=requestAnimationFrame(tick);
}
