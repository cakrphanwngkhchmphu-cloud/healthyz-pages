const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const smooth = value => value * value * (3 - 2 * value);
const wrap = value => ((value % 4) + 4) % 4;
export function nearestOrbitPosition(current, target) {
  let delta = wrap(target) - wrap(current);
  if (delta > 2) delta -= 4;
  if (delta < -2) delta += 4;
  return current + delta;
}
const flatPlate = [12,13,200,-2,388,13,375,109,200,94,25,109];
// Native curved vectors from the saved Menu frame of the linked Figma file.
const leftPlate = [12,0,56,46,158,73,139,149,34,127,0,61];
const rightPlate = [0,73,100,42,140,0,156,62,133,121,17,149];
const frontPlate = [53,0,305,21,562,0,596,140,298,140,0,140];
function platePath(side, left, front) {
  const native = left ? leftPlate : rightPlate;
  const width = left ? 159 : 158;
  const p = flatPlate.map((value,i) => value * (1-side-front) + native[i] * (i % 2 ? 120 / 150 : 400 / width) * side + frontPlate[i] * (i % 2 ? 120 / 144 : 400 / 603) * front);
  return `M${p[0]} ${p[1]}Q${p[2]} ${p[3]} ${p[4]} ${p[5]}L${p[6]} ${p[7]}Q${p[8]} ${p[9]} ${p[10]} ${p[11]}Z`;
}

// One scroll position controls both the card orbit and the crossfade.
export function journeyFrame(position, reducedMotion = false, loop = false) {
  const finite = Number.isFinite(position) ? position : 0;
  const p = loop ? finite : clamp(finite, 0, 3);
  const active = wrap(Math.round(p));
  const low = Math.floor(p);
  const mix = smooth(p - low);
  return {
    position: p, active,
    chapters: Array.from({ length: 4 }, (_, i) => {
      const opacity = reducedMotion ? Number(i === active) : i === wrap(low) ? 1 - mix : i === wrap(low + 1) ? mix : 0;
      const offset = clamp(loop ? nearestOrbitPosition(p, i) - p : i - p, -1, 1);
      return { opacity, x: reducedMotion ? 0 : offset * 70, y: reducedMotion ? 0 : Math.abs(offset) * 28, scale: reducedMotion ? 1 : 1 - Math.abs(offset) * .12 };
    }),
    cards: Array.from({ length: 4 }, (_, i) => {
      const theta = (i - (reducedMotion ? active : p)) * Math.PI / 2;
      const depth = (Math.cos(theta) + 1) / 2;
      const sine = Math.sin(theta);
      const side = smooth(sine * sine);
      const left = sine < 0;
      const front = Math.max(0,Math.cos(theta)) * (1-side);
      return {
        x: .5 + sine * (520 / 1200 - .01765 * side),
        y: .5 + Math.cos(theta) * (240 / 680) + .12906 * side,
        rotateY: -sine * 68 * (1 - side), rotateZ: -sine * 12 * (1 - side),
        scale: (.76 + depth * .24) * (1 - side) + side,
        z: Math.round(depth * 20), depth, side, left, front, path: platePath(side,left,front)
      };
    })
  };
}
